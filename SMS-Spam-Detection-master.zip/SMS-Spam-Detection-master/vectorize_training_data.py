from FeatureModel import FeatureModel

def main():
    fm = FeatureModel()
    fm.compute_fv_matrix('training')
    

main()
