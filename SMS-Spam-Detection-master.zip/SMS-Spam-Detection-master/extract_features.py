from FeatureModel import FeatureModel

def main():
    fm = FeatureModel()
    fm.extract_features()
    

main()
